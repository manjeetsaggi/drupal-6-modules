Extract the syntaxhighlighter javascript library file here. When completed, there should be these
directories and files:
scripts/
src/
styles/
test.html