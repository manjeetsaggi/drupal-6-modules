REQUIREMENTS
-------------

Download the latest Syntax Highlighter javascript library from http://alexgorbatchev.com/wiki/SyntaxHighlighter,
extract the content and place it inside the syntaxhighlighter directory this module's directory.

In the end,  you should have a directory structure like this:

syntaxhighlighter
  README.txt
  syntaxhighlighter.admin.inc
  syntaxhighlighter.info
  syntaxhighlighter.install
  syntaxhighlighter.module
  syntaxhighlighter/
    scripts/
      shCore.js
      ....
    styles/

NOTES
-----

You must use the Full HTML format because the HTML filter modifies the class attribute.